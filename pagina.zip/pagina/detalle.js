var parametros = new URLSearchParams(location.search);
var recetaId = parametros.get('id') || '53050';

var tituloReceta = document.getElementById('titulo');
var categoriaReceta = document.getElementById('categoria');
var imagenReceta = document.getElementById('foto');
var listaIngredientes = document.getElementById('ingredientes');
var listaPasos = document.getElementById('pasos');
var lineaOrigen = document.getElementById('origen-linea');
var lineaClima = document.getElementById('clima-linea');

function convertirAElementoLi(texto) {
  return '<li>' + texto + '</li>';
}

function obtenerJSON(url, cuandoOk, cuandoError) {
  fetch(url)
    .then(function(respuesta){ return respuesta.json(); })
    .then(function(datos){ cuandoOk(datos); })
    .catch(function(){ if (cuandoError) { cuandoError(); } });
}

function cargarDetalleReceta() {
  var url = 'https://www.themealdb.com/api/json/v1/1/lookup.php?i=' + encodeURIComponent(recetaId);
  obtenerJSON(url, function(datos){
    var receta = (datos.meals && datos.meals[0]) ? datos.meals[0] : null;
    if (!receta) {
      tituloReceta.textContent = 'No se pudo cargar la receta.';
      return;
    }

    tituloReceta.textContent = receta.strMeal || 'Receta';
    var textoCategoria = receta.strCategory ? receta.strCategory : '';
    var textoArea = receta.strArea ? ' • ' + receta.strArea : '';
    categoriaReceta.textContent = (textoCategoria + textoArea).trim();
    imagenReceta.src = receta.strMealThumb || '';

    // Ingredientes
    var htmlIngredientes = '';
    for (var i = 1; i <= 20; i++) {
      var nombreIng = receta['strIngredient' + i];
      var medidaIng = receta['strMeasure' + i];
      if (nombreIng && nombreIng.trim() !== '') {
        var textoIng = nombreIng;
        if (medidaIng && medidaIng.trim() !== '') {
          textoIng += ' — ' + medidaIng;
        }
        htmlIngredientes += convertirAElementoLi(textoIng);
      }
    }
    listaIngredientes.innerHTML = htmlIngredientes;

    var htmlPasos = '';
    var textoInstrucciones = receta.strInstructions || '';
    var lineas = textoInstrucciones.split(/\r?\n/);
    for (var p = 0; p < lineas.length && p < 12; p++) {
      if (lineas[p].trim() !== '') {
        htmlPasos += convertirAElementoLi(lineas[p]);
      }
    }
    listaPasos.innerHTML = htmlPasos;

    // Guardar el area 
    window._areaReceta = receta.strArea || '';

    cargarOrigenYClima(); // pais y clima
  }, function(){
    tituloReceta.textContent = 'No se pudo cargar la receta.';
  });
}

function cargarOrigenYClima() {
  
  var areaAPais = {
    'American':'United States', 'British':'United Kingdom', 'Canadian':'Canada', 'Chinese':'China', 'Croatian':'Croatia',
    'Dutch':'Netherlands', 'Egyptian':'Egypt', 'Filipino':'Philippines', 'French':'France', 'Greek':'Greece',
    'Indian':'India', 'Irish':'Ireland', 'Italian':'Italy', 'Jamaican':'Jamaica', 'Japanese':'Japan', 'Kenyan':'Kenya',
    'Malaysian':'Malaysia', 'Mexican':'Mexico', 'Moroccan':'Morocco', 'Polish':'Poland', 'Portuguese':'Portugal',
    'Russian':'Russia', 'Spanish':'Spain', 'Thai':'Thailand', 'Tunisian':'Tunisia', 'Turkish':'Turkey', 'Vietnamese':'Viet Nam'
  };

  var nombrePais = areaAPais[window._areaReceta] || window._areaReceta || 'Italy';
  var urlRestCountries = 'https://restcountries.com/v3.1/name/' + encodeURIComponent(nombrePais) + '?fields=name,flags,languages,capital,capitalInfo';

  obtenerJSON(urlRestCountries, function(datosPais){
    var pais = Array.isArray(datosPais) ? datosPais[0] : datosPais;
    var urlBandera = (pais && pais.flags && pais.flags.svg) ? pais.flags.svg : '';
    var nombreComun = (pais && pais.name && pais.name.common) ? pais.name.common : nombrePais;
    var idiomas = (pais && pais.languages) ? Object.values(pais.languages).join(', ') : 'N/D';
    var capital = (pais && pais.capital && pais.capital[0]) ? pais.capital[0] : 'N/D';

    var htmlOrigen = '';
    if (urlBandera !== '') {
      htmlOrigen += '<img src="' + urlBandera + '" alt="Bandera de ' + nombreComun + '" class="w-7 h-5 object-cover border rounded inline-block mr-2 align-middle">';
    }
    htmlOrigen += '<strong>País:</strong> ' + nombreComun + ' — <strong>Idiomas:</strong> ' + idiomas + ' — <strong>Capital:</strong> ' + capital;
    lineaOrigen.innerHTML = htmlOrigen;

    // Coordenadas de la capital parael  clima
    var latitud = null;
    var longitud = null;
    if (pais && pais.capitalInfo && Array.isArray(pais.capitalInfo.latlng) && pais.capitalInfo.latlng.length === 2) {
      latitud = pais.capitalInfo.latlng[0];
      longitud = pais.capitalInfo.latlng[1];
    }

    if (latitud !== null && longitud !== null) {
      cargarClima(latitud, longitud);
    } else {
      lineaClima.textContent = 'No hay coordenadas de la capital.';
    }
  }, function(){
    lineaOrigen.textContent = 'No se pudo cargar el origen.';
    lineaClima.textContent = '';
  });
}

function cargarClima(latitud, longitud) {
  var urlOpenMeteo = 'https://api.open-meteo.com/v1/forecast?latitude=' + latitud + '&longitude=' + longitud + '&current_weather=true';
  obtenerJSON(urlOpenMeteo, function(datosClima){
    var climaActual = datosClima.current_weather;
    if (climaActual && typeof climaActual.temperature !== 'undefined') {
      lineaClima.textContent = climaActual.temperature + ' °C';
    } else {
      lineaClima.textContent = 'Clima no disponible.';
    }
  }, function(){
    lineaClima.textContent = 'Clima no disponible.';
  });
}

cargarDetalleReceta();
