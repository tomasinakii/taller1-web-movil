var listaRecetas = document.getElementById('lista-recetas');
var formularioBuscar = document.getElementById('form-buscar');
var inputBuscar = document.getElementById('input-buscar');
var botonesFiltro = document.querySelectorAll('.chip');

function crearTarjetaReceta(receta) {
  var html = '';
  html += '<article class="card">';
  html += '  <img src="' + (receta.strMealThumb || '') + '" alt="Foto de ' + (receta.strMeal || '') + '" loading="lazy">';
  html += '  <div class="body">';
  html += '    <h3 class="title">' + (receta.strMeal || '') + '</h3>';
  html += '    <p class="text-sm text-gray-600">' + (receta.strCategory || '') + '</p>';
  html += '    <a href="./detalle.html?id=' + (receta.idMeal || '') + '" class="mt-2 inline-block bg-green-600 text-white text-sm px-3 py-2 rounded-md hover:bg-green-700">Ver detalle</a>';
  html += '  </div>';
  html += '</article>';
  return html;
}

function mostrarRecetasEnPantalla(arregloRecetas) {
  var contenido = '';
  for (var i = 0; i < arregloRecetas.length; i++) {
    contenido += crearTarjetaReceta(arregloRecetas[i]);
  }
  listaRecetas.innerHTML = contenido;
}

function buscarPorTexto(texto) {
  var url = 'https://www.themealdb.com/api/json/v1/1/search.php?s=' + encodeURIComponent(texto);
  fetch(url)
    .then(function(respuesta){ return respuesta.json(); })
    .then(function(datos){
      var recetas = datos.meals || [];
      mostrarRecetasEnPantalla(recetas);
    })
    .catch(function(){
      listaRecetas.innerHTML = '<p class="text-sm text-red-600">No se pudo cargar.</p>';
    });
}

function filtrarPorCategoria(nombreCategoria) {
  var url = 'https://www.themealdb.com/api/json/v1/1/filter.php?c=' + encodeURIComponent(nombreCategoria);
  fetch(url)
    .then(function(respuesta){ return respuesta.json(); })
    .then(function(datos){
      var recetas = datos.meals || [];
      mostrarRecetasEnPantalla(recetas);
    })
    .catch(function(){
      listaRecetas.innerHTML = '<p class="text-sm text-red-600">No se pudo cargar.</p>';
    });
}

formularioBuscar.addEventListener('submit', function(evento){
  evento.preventDefault();
  var texto = inputBuscar.value.trim();
  if (texto === '') { texto = 'chicken'; }
  buscarPorTexto(texto);
});

for (var i = 0; i < botonesFiltro.length; i++) {
  (function(boton){
    boton.addEventListener('click', function(){
      if (boton.classList.contains('activa')) {
        boton.classList.remove('activa');
        buscarPorTexto('chicken'); // volver al estado inicial
      } else {
        for (var j = 0; j < botonesFiltro.length; j++) {
          botonesFiltro[j].classList.remove('activa');
        }
        boton.classList.add('activa');
        var categoria = boton.getAttribute('data-cat');
        filtrarPorCategoria(categoria);
      }
    });
  })(botonesFiltro[i]);
}

// Carga inicial
buscarPorTexto('chicken');
